import CookieConsent from './components/CookieConsent'

export default CookieConsent
